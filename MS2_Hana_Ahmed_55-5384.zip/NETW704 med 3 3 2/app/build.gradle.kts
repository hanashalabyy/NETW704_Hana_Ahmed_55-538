import com.android.tools.r8.internal.de

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    id("com.google.gms.google-services")
}

android {

    namespace = "com.example.netw704"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.netw704"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures {
        compose = true
        viewBinding= true
    }
}

dependencies {

    implementation ("androidx.camera:camera-core:${"1.2.2"}")
    implementation( "androidx.camera:camera-camera2:${"1.2.2"}")
    implementation ("androidx.camera:camera-lifecycle:${"1.2.2"}")
    implementation ("androidx.camera:camera-video:${"1.2.2"}")

    implementation( "androidx.camera:camera-view:${"1.2.2"}")
    implementation ("androidx.camera:camera-extensions:${"1.2.2"}")


    //imgur
    implementation(libs.retrofit)
    implementation(libs.retrofit.converter.gson)
    implementation(libs.okhttp)
    implementation(libs.okhttp.logging)
    implementation(libs.gson)

    //glide
    implementation(libs.glide)
    implementation(libs.androidx.camera.lifecycle)
    implementation(libs.androidx.camera.view)
    implementation(libs.androidx.cardview)
    annotationProcessor(libs.glideCompiler)



    // AndroidX core libraries
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)





    // Compose libraries
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)

    // Firebase dependencies
    //implementation(platform(libs.firebase.bom))  // Firebase BOM for version alignment
    //implementation(libs.firebase.auth)  // Firebase Authentication
    implementation(libs.firebase.common.ktx)  // Firebase common utilities
    implementation(platform(libs.firebase.bom.v3111))
    implementation(libs.firebase.auth.ktx)


    // Google Maps
    implementation(libs.play.services.maps)  // Google Play services - Maps

    // UI and AppCompat
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.constraintlayout)

    // Networking (Volley)
    implementation(libs.volley)
    implementation(libs.androidx.activity)
    implementation(libs.play.services.analytics.impl)
    implementation(libs.androidx.recyclerview)
    implementation("de.hdodenhof:circleimageview:3.1.0")
    implementation("com.github.furkankaplan:fk-blur-view-android:1.0.1")
    implementation(libs.firebase.crashlytics.buildtools)  // For making network requests

    // Testing libraries
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.ui.test.junit4)

    // Debugging
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)

    // Import the BoM for the Firebase platform
    implementation(platform(libs.firebase.bom.v3351))

    // Add the dependency for the Realtime Database library
    // When using the BoM, you don't specify versions in Firebase library dependencies
    implementation(libs.firebase.database)

    }

//    implementation(com.google.android.material:material:1.1.0)

