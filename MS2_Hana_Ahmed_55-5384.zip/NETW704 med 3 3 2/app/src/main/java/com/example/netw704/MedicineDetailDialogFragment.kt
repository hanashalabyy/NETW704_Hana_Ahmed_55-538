package com.example.netw704

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.netw704.fragments.adapters.RetrofitClient
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MedicineDetailDialogFragment : DialogFragment() {

    private lateinit var medicine: meds
    private lateinit var productsReference: DatabaseReference
    private var isApproved: Boolean = false
    private val REQUEST_CAMERA = 101
    private val REQUEST_GALLERY = 102
    private val PERMISSION_REQUEST_CODE = 100
    private var imageUri: Uri? = null
    private lateinit var currentPhotoPath: String
    private lateinit var progressBar: ProgressBar
    private lateinit var medicineImageView: ImageView
    private lateinit var saveButton: Button
    private lateinit var exitButton: Button

    companion object {
        fun newInstance(medicine: meds, isApproved: Boolean): MedicineDetailDialogFragment {
            val fragment = MedicineDetailDialogFragment()
            val args = Bundle().apply {
                putString("name", medicine.name)
                putFloat("price", medicine.price)
                putString("img", medicine.img)
                putInt("quantity", medicine.quantity)
                putBoolean("isApproved", isApproved)
            }
            fragment.arguments = args
            return fragment
        }
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.dialog_medicine_detail, container, false)

        // Initialize Firebase reference
        productsReference = FirebaseDatabase.getInstance().getReference("products")

        medicine = meds(
            name = arguments?.getString("name") ?: "",
            price = arguments?.getFloat("price") ?: 0.0f,
            img = arguments?.getString("img") ?: "",
            quantity = arguments?.getInt("quantity") ?: 0
        )
        isApproved = arguments?.getBoolean("isApproved") ?: false

        // Set up views
        val medName: TextView = view.findViewById(R.id.medicineName)
        val medPrice: TextView = view.findViewById(R.id.medicinePrice)
        //val medPrice: TextView = view.findViewById(R.id.medicinePrice)
        val medImage: ImageView = view.findViewById(R.id.medimage)
        val editButton: Button = view.findViewById(R.id.editButton)
        val deleteButton: Button = view.findViewById(R.id.deleteButton)
        val exitbutton1: Button = view.findViewById(R.id.exitbutton)
        val medQuantity: TextView = view.findViewById(R.id.medicineQuantity)

        // Display the medicine details
        medName.text = medicine.name
        medPrice.text = "Price: ${medicine.price.toString()} EGP"
        medQuantity.text = "Quantity: ${medicine.quantity.toString()}"

        if (medicine.img.isNotEmpty()) {
            Glide.with(this).load(medicine.img).into(medImage)
        } else {
            medImage.setImageResource(R.drawable.ic_android_white_24dp)
        }
        exitbutton1.setOnClickListener{
            dismiss()
        }

        // Handle the edit button click
        editButton.setOnClickListener {
            // Create a new layout to edit medicine details
            val editView = LayoutInflater.from(requireContext()).inflate(R.layout.editmed, null)
            medicineImageView = editView.findViewById(R.id.medicineImageView)
            progressBar = editView.findViewById(R.id.progressBar)
            saveButton = editView.findViewById(R.id.savebutton)
            exitButton = editView.findViewById(R.id.exitButton)

            val medicineNameEditText: EditText = editView.findViewById(R.id.medicineNameEditText)
            val priceEditText: EditText = editView.findViewById(R.id.priceEditText)
            val quantityEditText: EditText = editView.findViewById(R.id.quantityEditText)

            // Pre-fill the fields with current data
            medicineNameEditText.setText(medicine.name)
            priceEditText.setText(medicine.price.toString())
            quantityEditText.setText(medicine.quantity.toString())

            // Show the edit layout in the dialog
            val dialogView = AlertDialog.Builder(requireContext())
                .setView(editView)
                .create()

            dialogView.show()

            // Handle Save button click
            saveButton.setOnClickListener {
                val updatedName = medicineNameEditText.text.toString()
                val updatedPrice = priceEditText.text.toString().toFloatOrNull()
                val updatedQuantity = quantityEditText.text.toString().toIntOrNull()

                if (updatedName.isNotEmpty() && updatedPrice != null && updatedQuantity != null) {
                    if (imageUri != null) {
                        // Show progress bar
                        progressBar.visibility = View.VISIBLE

                        lifecycleScope.launch {
                            val imageFile = convertUriToFile(imageUri!!)
                            val imageUrl = uploadImageToImgur(imageFile)
                            progressBar.visibility = View.GONE

                            if (imageUrl != null) {
                                updateMedicineInDatabase(
                                    updatedName,
                                    updatedPrice,
                                    updatedQuantity,
                                    imageUrl
                                )
                                Toast.makeText(requireContext(), "Medicine updated successfully", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(requireContext(), "Image upload failed", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } else {
                        updateMedicineInDatabase(
                            updatedName,
                            updatedPrice,
                            updatedQuantity,
                            medicine.img)
                        Toast.makeText(requireContext(), "Medicine updated successfully", Toast.LENGTH_SHORT).show()

                    }
                } else {
                    Toast.makeText(requireContext(), "Invalid input. Please fill all fields correctly.", Toast.LENGTH_SHORT).show()
                }
            }

            // Handle Exit button click (closes all forms and goes back)
            exitButton.setOnClickListener {
                dialogView.dismiss()  // Close the dialog when exit is clicked
            }

            // Handle image upload
            val uploadButton: Button = editView.findViewById(R.id.uploadimageButton)
            uploadButton.setOnClickListener {
                chooseImageSource()
            }
        }

        // Handle delete button click
        deleteButton.setOnClickListener {
            deleteMedicine(medicine)
            Toast.makeText(requireContext(), "${medicine.name} deleted successfully", Toast.LENGTH_SHORT).show()
            dismiss()  // Close the dialog after deleting
        }

        return view
    }

    private fun chooseImageSource() {
        val options = arrayOf("Take Photo", "Choose from Gallery")
        context?.let { ctx ->
            val builder = AlertDialog.Builder(ctx)
            builder.setTitle("Choose Image Source")
            builder.setItems(options) { _, which ->
                when (which) {
                    0 -> openCamera()
                    1 -> openGallery()
                }
            }
            builder.show()
        }
    }

    private fun openCamera() {
        val photoFile: File? = try {
            createImageFile()
        } catch (ex: IOException) {
            Log.e("Camera", "Error creating file", ex)
            null
        }

        photoFile?.also {
            val photoUri: Uri = FileProvider.getUriForFile(
                requireContext(),
                "com.example.netw704.fileprovider",
                it
            )
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
            }
            startActivityForResult(cameraIntent, REQUEST_CAMERA)
        }
    }

    private fun openGallery() {
        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(galleryIntent, REQUEST_GALLERY)

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_CAMERA -> {
                    imageUri = Uri.fromFile(File(currentPhotoPath)) // Get Uri of captured image
                    medicineImageView.setImageURI(imageUri) // Display the image
                }
                REQUEST_GALLERY -> {
                    imageUri = data?.data
                    medicineImageView.setImageURI(imageUri)
                }
            }
        }
    }

    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timestamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir: File = requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        return File.createTempFile("JPEG_${timestamp}_", ".jpg", storageDir).apply {
            currentPhotoPath = absolutePath
        }
    }

    private fun convertUriToFile(uri: Uri): File {
        val inputStream = requireContext().contentResolver.openInputStream(uri)
        val tempFile = File(requireContext().cacheDir, "temp_image.jpg")
        inputStream?.use { input ->
            tempFile.outputStream().use { output ->
                input.copyTo(output)
            }
        }
        return tempFile
    }

    private suspend fun uploadImageToImgur(imageFile: File): String? {
        val authHeader = "Client-ID 0465aaf2c983df2"
        val requestFile = RequestBody.create("image/*".toMediaTypeOrNull(), imageFile)
        val body = MultipartBody.Part.createFormData("image", imageFile.name, requestFile)

        try {
            val response = RetrofitClient.instance.uploadImage(authHeader, body)
            if (response.isSuccessful) {
                return response.body()?.data?.link
            } else {
                Log.e("Imgur", "Upload failed: ${response.message()}")
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("Imgur", "Upload exception: ${e.message}")
        }
        return null
    }


    private fun updateMedicineInDatabase(
        updatedName: String, updatedPrice: Float, updatedQuantity: Int, imageUrl: String
    ) {
        productsReference.orderByChild("name").equalTo(medicine.name).addListenerForSingleValueEvent(object :
            ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    snapshot.children.forEach { medicineSnapshot ->
                        medicineSnapshot.ref.child("name").setValue(updatedName)
                        medicineSnapshot.ref.child("price").setValue(updatedPrice)
                        medicineSnapshot.ref.child("quantity").setValue(updatedQuantity)
                        medicineSnapshot.ref.child("img").setValue(imageUrl)
                    }
                    dismiss()
                    Toast.makeText(context, "Medicine edited successfully", Toast.LENGTH_SHORT).show()
                    dismiss()
                      // Close the dialog after saving the data


                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun deleteMedicine(medicine: meds) {
        productsReference.orderByChild("name").equalTo(medicine.name).addListenerForSingleValueEvent(object :
            ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    snapshot.children.forEach { medicineSnapshot ->
                        medicineSnapshot.ref.removeValue()
                    }
                    dismiss()  // Close the dialog after deleting
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
