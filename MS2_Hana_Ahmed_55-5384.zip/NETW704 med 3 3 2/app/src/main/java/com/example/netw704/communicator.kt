package com.example.netw704

interface communicator {
}