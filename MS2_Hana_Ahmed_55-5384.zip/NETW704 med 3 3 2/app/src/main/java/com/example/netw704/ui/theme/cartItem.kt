package com.example.netw704.models

data class CartItem(
    val medicineName: String = "",
    var requestedQuantity: Int = 0,
    val price: Float = 0.0f,
    val patientName: String = "",
    val medicineimage: String = ""
) {
    // Calculate totalPrice dynamically
    val totalPrice: Float
        get() = requestedQuantity * price
}
