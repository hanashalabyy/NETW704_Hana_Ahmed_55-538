package com.example.netw704.ui.theme;

import android.app.Activity;

public class ProfilePatient extends Activity {
}
