package com.example.netw704

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class Login : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Initialize Firebase Auth and Database reference
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().getReference("Users")

        // UI elements
        val emailAddressIn: EditText = findViewById(R.id.emailAddressLogin)
        val passwordIn: EditText = findViewById(R.id.passwordLogin)
        val loginButton: Button = findViewById(R.id.login)
        val mapButton: Button = findViewById(R.id.signup)

        // Navigate to register activity
        mapButton.setOnClickListener {
            val intent = Intent(this, Register::class.java)
            startActivity(intent)
        }

        // Handle login
        loginButton.setOnClickListener {
            val emailAddress = emailAddressIn.text.toString()
            val password = passwordIn.text.toString()

            // Validate inputs
            if (emailAddress.isNotEmpty() && password.isNotEmpty()) {
                signInUser(emailAddress, password)
            } else {
                Toast.makeText(this, "Please enter both email and password", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun signInUser(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Login successful, now retrieve user info
                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()
                    retrieveUserInfo(email)
                } else {
                    // Login failed, show error message
                    Toast.makeText(this, "Login failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun retrieveUserInfo(email: String) {
        // Query the database for the user with the given email
        database.orderByChild("email").equalTo(email)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        // Loop through results (there should be only one user in this case)
                        for (userSnapshot in snapshot.children) {
                            val name = userSnapshot.child("name").getValue(String::class.java)
                           // val age = userSnapshot.child("age").getValue(Int::class.java)
                            val gender = userSnapshot.child("gender").getValue(String::class.java)
                            val type = userSnapshot.child("type").getValue(String::class.java)

                            // Display user info (Optional)
                            Toast.makeText(
                                this@Login,
                                "Welcome, $name!",
                                Toast.LENGTH_LONG
                            ).show()

                            // Navigate to the correct activity based on user type
                            if (type == "Doctor") {
                                // Navigate to Doctor activity
                                val intent = Intent(this@Login, Doctor::class.java)
                                    .putExtra("email", email)
                                startActivity(intent)
                            } else if (type == "Patient") {
                                // Navigate to Patient activity
                                val intent = Intent(this@Login, Patient::class.java)
                                    .putExtra("email", email)
                                startActivity(intent)
                            } else {
                                // Invalid user type, show error
                                Toast.makeText(this@Login, "User type not found.", Toast.LENGTH_SHORT).show()
                            }

                            // Optionally finish the login activity to prevent user from going back
                            finish()
                        }
                    } else {
                        // User not found in the database
                        Toast.makeText(
                            this@Login,
                            "User not found. Please register.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@Login, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }
}
