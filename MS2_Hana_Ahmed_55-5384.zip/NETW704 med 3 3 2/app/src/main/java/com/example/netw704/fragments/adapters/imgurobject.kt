package com.example.netw704.fragments.adapters

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import okhttp3.OkHttpClient
import okhttp3.Request

object RetrofitClient {
    private const val BASE_URL = "https://api.imgur.com/" // Base URL for Imgur API

    val instance: ImgurApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        retrofit.create(ImgurApiService::class.java) // Creating the Retrofit instance
    }
}
