package com.example.netw704

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class Register : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().getReference("Users")

        val emailEditText: EditText = findViewById(R.id.emailAddressRegister)
        val passwordEditText: EditText = findViewById(R.id.passwordRegister)
        val registerButton: Button = findViewById(R.id.register)
        val loginButton: Button = findViewById(R.id.logins)
        val nameEditText: EditText = findViewById(R.id.name)
        val ageEditText: EditText = findViewById(R.id.age)
        val genderRadioGroup: RadioGroup = findViewById(R.id.which)
        val typeRadioGroup: RadioGroup = findViewById(R.id.type)

        loginButton.setOnClickListener {
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }

        registerButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()
            val name = nameEditText.text.toString().trim()
            val age = ageEditText.text.toString().trim()
            val gender = when (genderRadioGroup.checkedRadioButtonId) {
                R.id.MALE -> "Male"
                R.id.FEMALE -> "Female"
                else -> ""
            }
            val type = when (typeRadioGroup.checkedRadioButtonId) {
                R.id.doctor -> "Doctor"
                R.id.patient -> "Patient"
                else -> ""
            }

            // Validate inputs
            if (email.isNotEmpty() && password.isNotEmpty()) {
                if (password.length >= 6) {
                    // Register user with Firebase
                    registerUser(email, password, name, age, gender, type)
                } else {
                    Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun registerUser(email: String, password: String, name: String, age: String, gender: String, type: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Registration success, navigate to the corresponding activity
                    Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show()

                    // Save user details to the Firebase Realtime Database
                    saveUserToDatabase(email, name, age, gender, type)

                    // Redirect based on user type (Doctor or Patient)
                    val intent = if (type == "Doctor") {
                        Intent(this, Doctor::class.java)
                            .putExtra("email", email)
                    } else {
                        Intent(this, Patient::class.java)
                            .putExtra("email", email)
                    }
                    startActivity(intent)
                    finish()  // Close the RegisterActivity
                } else {
                    // Registration failed, show error message
                    Toast.makeText(this, "Registration failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun saveUserToDatabase(email: String, name: String, age: String, gender: String, type: String) {
        val userId = database.push().key
        val image = ""

        if (userId != null) {
            val user = User(email, name, age.toInt(), gender, type, image)

            // Save the user object to the Firebase Realtime Database
            database.child(userId).setValue(user)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "User registered successfully!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Failed to register user: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
        } else {
            Toast.makeText(this, "Failed to generate user ID", Toast.LENGTH_SHORT).show()
        }
    }
}
