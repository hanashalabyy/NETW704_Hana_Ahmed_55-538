package com.example.netw704.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.netw704.R
import com.example.netw704.meds

class productAdapter(
    private val medsList: List<meds>,
    private val onItemClick: (meds) -> Unit // Click listener
) : RecyclerView.Adapter<productAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val medName: TextView = itemView.findViewById(R.id.medNameTextView)
        //val medPrice: TextView = itemView.findViewById(R.id.medPriceTextView)
        val medImage: ImageView = itemView.findViewById(R.id.medImageView)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.product_card_view, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val med = medsList[position]
        holder.medName.text = med.name
        val imageView = holder.medImage // Your ImageView ID
        if(med.img != ""){
            // Load the image URL into the ImageView using Glide
            Glide.with(holder.itemView.context)
                .load(med.img) // Load the image from the URL
                .into(imageView)
        }
        else {
            //holder.medPrice.text = med.price
            imageView.setImageResource(R.drawable.ic_android_black_24dp)
            // Load image if available (placeholder otherwise)
        }
        // Set click listener for the item
        holder.itemView.setOnClickListener {
            onItemClick(med)
        }
    }



    override fun getItemCount(): Int = medsList.size
}
