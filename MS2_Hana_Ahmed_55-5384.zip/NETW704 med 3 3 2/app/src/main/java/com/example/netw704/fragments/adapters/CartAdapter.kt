import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.netw704.R
import com.example.netw704.models.CartItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class CartAdapter(private val cartItems: List<CartItem>) :
    RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    inner class CartViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val medicineNameTextView: TextView = itemView.findViewById(R.id.medicineNameTextView)
        val quantityTextView: TextView = itemView.findViewById(R.id.quantityTextView)
        val priceTextView: TextView = itemView.findViewById(R.id.priceTextView)
        val removeButton: Button = itemView.findViewById(R.id.removeButton)
        var medImageView: ImageView = itemView.findViewById(R.id.medImageView)
        val decreaseB: Button = itemView.findViewById(R.id.decreaseButton)
        val increaseB: Button = itemView.findViewById(R.id.increaseButton)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cart, parent, false)
        return CartViewHolder(view)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val item = cartItems[position]
        holder.medicineNameTextView.text = item.medicineName
        holder.quantityTextView.text = "Quantity: ${item.requestedQuantity}"
        holder.priceTextView.text = "Price: $${item.price * item.requestedQuantity}"


        if (item.medicineimage != "") {
            // Load the image URL into the ImageView using Glide

            Glide.with(holder.itemView.context)
                .load(item.medicineimage) // Load the image from the URL
                .into(holder.medImageView)
        } else {
            //holder.medPrice.text = med.price
            holder.medImageView.setImageResource(R.drawable.ic_android_white_24dp)
            // Load image if available (placeholder otherwise)
        }

        holder.removeButton.setOnClickListener {
            // Pass the requestedQuantity when removing the item
            removeItemFromCart(item.medicineName, item.requestedQuantity, holder.itemView.context)
            removeitemformcart(item.medicineName, holder.itemView.context)

        }

        holder.decreaseB.setOnClickListener {
            if (item.requestedQuantity > 1) {
                item.requestedQuantity--
                holder.quantityTextView.text = "Quantity: ${item.requestedQuantity}"
                holder.priceTextView.text = "Price: $${item.price * item.requestedQuantity}"
                decreaseQuantity(item.medicineName, holder.itemView.context)
            } else {
                Toast.makeText(
                    holder.itemView.context,
                    "Quantity cannot be less than 1",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        holder.increaseB.setOnClickListener {
            item.requestedQuantity++
            holder.quantityTextView.text = "Quantity: ${item.requestedQuantity}"
            holder.priceTextView.text = "Price: $${item.price * item.requestedQuantity}"
            increaseQuantity(item.medicineName, holder.itemView.context)
        }


    }


    override fun getItemCount(): Int = cartItems.size

    private fun removeItemFromCart(medicineName: String, requestedQuantity: Int, context: Context) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val cartRef =
            FirebaseDatabase.getInstance().getReference("cart").child(userId).child(medicineName)
        val productsRef = FirebaseDatabase.getInstance()
            .getReference("products")  // Reference to the products node

        // Remove the item from the cart
        cartRef.removeValue().addOnSuccessListener {
            // Search for the medicine in the products database and update the quantity
            productsRef.orderByChild("name").equalTo(medicineName)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.exists()) {
                            for (productSnapshot in snapshot.children) {
                                // Get the current quantity and increment it by the requested quantity
                                val currentQuantity =
                                    productSnapshot.child("quantity").getValue(Int::class.java) ?: 0
                                val updatedQuantity = currentQuantity + requestedQuantity
                                productSnapshot.ref.child("quantity").setValue(updatedQuantity)
                                    .addOnCompleteListener { task ->
                                        if (task.isSuccessful) {
                                            Toast.makeText(
                                                context,
                                                "Item removed and quantity updated.",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        } else {
                                            Toast.makeText(
                                                context,
                                                "Error updating quantity: ${task.exception?.message}",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }
                            }
                        } else {
                            Toast.makeText(
                                context,
                                "Medicine not found in the database.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Toast.makeText(context, "Error: ${error.message}", Toast.LENGTH_SHORT)
                            .show()
                    }
                })
        }.addOnFailureListener {
            Toast.makeText(
                context,
                "Failed to remove item from cart: ${it.message}",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun removeitemformcart(medicineName: String, context: Context) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        // cartReference = FirebaseDatabase.getInstance().getReference("cart")

        val cartRef = FirebaseDatabase.getInstance().getReference("cart").child(userId)
            .orderByChild("medicineName").equalTo(medicineName)
        cartRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    snapshot.children.forEach { medicineSnapshot ->
                        medicineSnapshot.ref.removeValue()
                    }
                    //dismiss()  // Close the dialog after deleting
                }
            }

            override fun onCancelled(error: DatabaseError) {
                //Toast.makeText(requireContext(), "Error: ${error.message}", Toast.LENGTH_SHORT)
                //    .show()
            }
        })

    }

    private fun decreaseQuantity(medicineName: String, context: Context) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val cartRef =
            FirebaseDatabase.getInstance().getReference("cart").child(userId).child(medicineName)
        val productsRef = FirebaseDatabase.getInstance()
            .getReference("products")  // Reference to the products node

        cartRef.removeValue().addOnSuccessListener {
            // Search for the medicine in the products database and update the quantity
            productsRef.orderByChild("name").equalTo(medicineName)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.exists()) {
                            for (productSnapshot in snapshot.children) {
                                // Get the current quantity and increment it by the requested quantity
                                val currentQuantity =
                                    productSnapshot.child("quantity").getValue(Int::class.java) ?: 0
                                val updatedQuantity = currentQuantity + 1
                                productSnapshot.ref.child("quantity").setValue(updatedQuantity)
                                    .addOnCompleteListener { task ->
                                        if (task.isSuccessful) {
                                            Toast.makeText(
                                                context,
                                                "Item Quantity increased by 1 in product.",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        } else {
                                            Toast.makeText(
                                                context,
                                                "Error updating quantity: ${task.exception?.message}",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }
                            }
                        } else {
                            Toast.makeText(
                                context,
                                "Medicine not found in the database.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Toast.makeText(context, "Error: ${error.message}", Toast.LENGTH_SHORT)
                            .show()
                    }
                })
        }.addOnFailureListener {
            Toast.makeText(
                context,
                "Failed to remove item from cart: ${it.message}",
                Toast.LENGTH_SHORT
            ).show()
        }

        val cartRef2 = FirebaseDatabase.getInstance().getReference("cart").child(userId)
            .orderByChild("medicineName").equalTo(medicineName)
        cartRef2.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    for (productSnapshot in snapshot.children) {
                        // Get the current quantity and increment it by the requested quantity
                        val currentQuantity =
                            productSnapshot.child("requestedQuantity").getValue(Int::class.java) ?: 0
                        val updatedQuantity = currentQuantity - 1
                        productSnapshot.ref.child("requestedQuantity").setValue(updatedQuantity)
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    Toast.makeText(
                                        context,
                                        "Item Quantity decreased by 1 in cart.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        context,
                                        "Error updating quantity: ${task.exception?.message}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                    }
                } else {
                    Toast.makeText(
                        context,
                        "Medicine not found in the database.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
            //dismiss()  // Close the dialog after deleting

        })
    }



    private fun increaseQuantity(medicineName: String, context: Context) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val cartRef =
            FirebaseDatabase.getInstance().getReference("cart").child(userId).child(medicineName)
        val productsRef = FirebaseDatabase.getInstance()
            .getReference("products")  // Reference to the products node

        cartRef.removeValue().addOnSuccessListener {
            // Search for the medicine in the products database and update the quantity
            productsRef.orderByChild("name").equalTo(medicineName)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.exists()) {
                            for (productSnapshot in snapshot.children) {
                                // Get the current quantity and increment it by the requested quantity
                                val currentQuantity =
                                    productSnapshot.child("quantity").getValue(Int::class.java) ?: 0
                                val updatedQuantity = currentQuantity - 1
                                productSnapshot.ref.child("quantity").setValue(updatedQuantity)
                                    .addOnCompleteListener { task ->
                                        if (task.isSuccessful) {
                                            Toast.makeText(
                                                context,
                                                "Item Quantity decreased by 1 in product.",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        } else {
                                            Toast.makeText(
                                                context,
                                                "Error updating quantity: ${task.exception?.message}",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }
                            }
                        } else {
                            Toast.makeText(
                                context,
                                "Medicine not found in the database.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Toast.makeText(context, "Error: ${error.message}", Toast.LENGTH_SHORT)
                            .show()
                    }
                })
        }.addOnFailureListener {
            Toast.makeText(
                context,
                "Failed to remove item from cart: ${it.message}",
                Toast.LENGTH_SHORT
            ).show()
        }

        val cartRef2 = FirebaseDatabase.getInstance().getReference("cart").child(userId)
            .orderByChild("medicineName").equalTo(medicineName)
        cartRef2.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    for (productSnapshot in snapshot.children) {
                        // Get the current quantity and increment it by the requested quantity
                        val currentQuantity =
                            productSnapshot.child("requestedQuantity").getValue(Int::class.java) ?: 0
                        val updatedQuantity = currentQuantity + 1
                        productSnapshot.ref.child("requestedQuantity").setValue(updatedQuantity)
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    Toast.makeText(
                                        context,
                                        "Item Quantity increased by 1 in cart.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        context,
                                        "Error updating quantity: ${task.exception?.message}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                    }
                } else {
                    Toast.makeText(
                        context,
                        "Medicine not found in the database.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
            //dismiss()  // Close the dialog after deleting

        })


    }
}

//    .orderByChild("name").equalTo(medicine.name).addListenerForSingleValueEvent(object :
//        ValueEventListener {
//        override fun onDataChange(snapshot: DataSnapshot) {
//            if (snapshot.exists()) {
//                snapshot.children.forEach { medicineSnapshot ->
//                    medicineSnapshot.ref.removeValue()
//                }
//                dismiss()  // Close the dialog after deleting
//            }
//        }
//
//        override fun onCancelled(error: DatabaseError) {
//            Toast.makeText(requireContext(), "Error: ${error.message}", Toast.LENGTH_SHORT).show()
//        }
//    })




//    private fun buyItemFromCart(medicineName: String, context: Context) {
//        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
//        val cartRef = FirebaseDatabase.getInstance().getReference("cart").child(userId).child(medicineName)
//        cartRef.removeValue().addOnSuccessListener {
//            Toast.makeText(context, "${medicineName} bought", Toast.LENGTH_SHORT).show()
//        }.addOnFailureListener {
//            Toast.makeText(context, "Failed to buy ${medicineName}: ${it.message}", Toast.LENGTH_SHORT).show()
//            }
//        }
//}