package com.example.netw704

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.viewpager.widget.ViewPager
import com.example.netw704.Login
import com.example.netw704.Profile
import com.example.netw704.R
import com.example.netw704.fragments.adapters.ViewPagerAdapter
import com.example.netw704.fragments.cartFragment
import com.example.netw704.fragments.chatFragmentpatient
import com.example.netw704.fragments.medicineFragmentpatient
import com.google.android.material.navigation.NavigationView
import com.google.android.material.tabs.TabLayout

class Patient : AppCompatActivity() {

    private lateinit var viewPager: ViewPager
    private lateinit var tabs: TabLayout
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var toolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_patient)

        // Initialize DrawerLayout, Toolbar, and NavigationView
        drawerLayout = findViewById(R.id.drawer_layout)
        toolbar = findViewById(R.id.toolbar)
        val navigationView: NavigationView = findViewById(R.id.nav_view)

        // Set the Toolbar as the app bar
        setSupportActionBar(toolbar)

        // Set up the ActionBarDrawerToggle for the hamburger menu
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        // Set up ViewPager and Tabs
        viewPager = findViewById(R.id.viewPager)
        tabs = findViewById(R.id.tabs)
        setUpTabs()

        // Set the navigation item click listener
        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_logout -> {
                    // Handle logout action
                    val intent = Intent(this, Login::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish() // Close the current activity
                }
                R.id.nav_about -> {
                    // Handle profile action
                    val intent = Intent(this, ProfilePatient::class.java) // Make sure you have a Profile activity
                    startActivity(intent)
                }
                // Add more cases here if needed
            }
            // Close the drawer after an item is selected
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
    }

    private fun setUpTabs() {
        val adapter = ViewPagerAdapter(supportFragmentManager)
        adapter.addFragment(chatFragmentpatient(), "Chat")
        adapter.addFragment(medicineFragmentpatient(), "Medicines")
        adapter.addFragment(cartFragment(), "Cart")

        viewPager.adapter = adapter
        tabs.setupWithViewPager(viewPager)

        tabs.getTabAt(0)?.setIcon(R.drawable.baseline_chat_24)
        tabs.getTabAt(1)?.setIcon(R.drawable.baseline_add_box_24)
        tabs.getTabAt(2)?.setIcon(R.drawable.baseline_add_shopping_car_24)
    }
}
