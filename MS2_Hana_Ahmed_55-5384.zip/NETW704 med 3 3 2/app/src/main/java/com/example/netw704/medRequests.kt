package com.example.netw704

data class medRequests(
    var name: String? = null,
    var nameOfPatient: String? = null,
    var reviewed: Boolean = false,
    var approved: Boolean = false,
    var img: String? = null
)
