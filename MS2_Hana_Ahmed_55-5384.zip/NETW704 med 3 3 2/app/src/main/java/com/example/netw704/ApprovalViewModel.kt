// ApprovalViewModel.kt
package com.example.netw704

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ApprovalViewModel : ViewModel() {

    // Holds the approval message that will be shared
    private val _approvalRequest = MutableLiveData<String>()
    val approvalRequest: LiveData<String> get() = _approvalRequest

    // Controls the visibility of the approval buttons
    private val _buttonsVisible = MutableLiveData<Boolean>()
    val buttonsVisible: LiveData<Boolean> get() = _buttonsVisible

    // Function to send an approval request message
    fun requestApproval(message: String) {
        _approvalRequest.value = message
        _buttonsVisible.value = true // Show the buttons
    }

    // Function to hide the approval buttons (decline logic, for example)
    fun hideApprovalButtons() {
        _buttonsVisible.value = false
    }
}
