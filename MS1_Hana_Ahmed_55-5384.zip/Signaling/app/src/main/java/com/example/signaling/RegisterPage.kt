package com.example.signaling

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth

class RegisterPage : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register_page)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        auth = FirebaseAuth.getInstance()

        val signUpButton = findViewById<Button>(R.id.buttonReg)
        val logbtn = findViewById<Button>(R.id.already)
        val email = findViewById<EditText>(R.id.email)
        val password = findViewById<EditText>(R.id.password)

        signUpButton.setOnClickListener {
            if (email.text.isEmpty() && password.text.isEmpty()) {
                Toast.makeText(this, "Info can not be blank", Toast.LENGTH_SHORT).show()
            } else {
                if (email.text.isEmpty() || password.text.isEmpty()) {
                    Toast.makeText(this, "Fill in the remaining info", Toast.LENGTH_SHORT).show()
                } else {
                    auth.createUserWithEmailAndPassword(email.text.toString(), password.text.toString()).addOnCompleteListener(this) {
                            if (it.isSuccessful) {
                                Toast.makeText(this, "Signed Up Successfully", Toast.LENGTH_SHORT).show()
                                val intentregsiter = Intent(this, LoginPage::class.java)
                                startActivity(intentregsiter)
                            }
                        }
                }

                logbtn.setOnClickListener {
                    val intentlog = Intent(this, LoginPage::class.java)
                    startActivity(intentlog)
                }
            }
        }
    }
}