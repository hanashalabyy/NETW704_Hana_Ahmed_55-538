package com.example.signaling

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ProfilePage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        val bioStored = intent.getStringExtra("user_bio")

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_profile_page)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val bio = findViewById<EditText>(R.id.bio)
        val edit = findViewById<Button>(R.id.edit)
        val save = findViewById<Button>(R.id.save)
        val back = findViewById<Button>(R.id.back)

        // Retrieve bio from SharedPreferences
        val sharedPreferences = getSharedPreferences("user_bio", MODE_PRIVATE)
        val storedBio = sharedPreferences.getString("user_bio", "")
        bio.setText(storedBio)

        bio.isEnabled = false

        edit.setOnClickListener {
            bio.isEnabled = true
        }

        save.setOnClickListener {
            val bioString = bio.text.toString()  // awel ma ados save by save ely fl bio
            if (bioString.isBlank()) {
                Toast.makeText(this, "Bio cannot be empty!", Toast.LENGTH_SHORT).show()
            } else {
                val bioStored = bioString    //value passed between el pages
                val editedBio = sharedPreferences.edit()
                editedBio.putString("user_bio", bioStored)
                editedBio.apply()
                bio.isEnabled = false
                Toast.makeText(this, "Bio saved!", Toast.LENGTH_SHORT).show()
            }
        }

        back.setOnClickListener {
            val backIntent = Intent(this, AfterLogin::class.java)
            backIntent.putExtra("user_bio", bioStored)
            startActivity(backIntent)
        }
    }
}